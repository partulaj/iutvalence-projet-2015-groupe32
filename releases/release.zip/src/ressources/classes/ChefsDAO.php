<?php
class ChefsDAO extends DAO {
	protected $table = "Chefs";
	protected $class = "Chef";
}
?>