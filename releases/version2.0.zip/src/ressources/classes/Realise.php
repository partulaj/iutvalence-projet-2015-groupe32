<?php
class Realise extends TableObject {
	static public $keyFieldsNames = array('no_tache','login_etudiant'); // par défaut un seul champ
	public $hasAutoIncrementedKey = false;
}
?>