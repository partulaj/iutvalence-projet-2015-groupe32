<?php
class TachesDAO extends DAO {
	protected $table = "Taches";
	protected $class = "Tache";
}
?>