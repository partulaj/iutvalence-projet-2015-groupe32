INSERT INTO Enseignants VALUES ('ens1','Hatake','Kakashi','ens1','');
INSERT INTO Enseignants VALUES ('ens2','Uchiha','Madara','ens2','');
INSERT INTO Enseignants VALUES ('ens3','Sarutobi','Asuma','ens3','');
INSERT INTO Enseignants VALUES ('ens4','Senju','Tobirama','ens4','');
INSERT INTO Enseignants VALUES ('ens5','Yuhi','Kurenai','ens5','');

INSERT INTO Etudiants(login_etudiant,nom_etudiant,prenom_etudiant,mdp_etudiant,mail_etudiant,classement) VALUES ('etu1','Dragneel','Natsu','etu1','','14');
INSERT INTO Etudiants(login_etudiant,nom_etudiant,prenom_etudiant,mdp_etudiant,mail_etudiant,classement) VALUES ('etu2','Strauss','Elfman','etu2','','13');
INSERT INTO Etudiants(login_etudiant,nom_etudiant,prenom_etudiant,mdp_etudiant,mail_etudiant,classement) VALUES ('etu3','Strauss','Lisanna','etu3','','6');
INSERT INTO Etudiants(login_etudiant,nom_etudiant,prenom_etudiant,mdp_etudiant,mail_etudiant,classement) VALUES ('etu4','Strauss','Mirajane','etu4','','7');
INSERT INTO Etudiants(login_etudiant,nom_etudiant,prenom_etudiant,mdp_etudiant,mail_etudiant,classement) VALUES ('etu5','Heartfilia','Lucy','etu5','','8');
INSERT INTO Etudiants(login_etudiant,nom_etudiant,prenom_etudiant,mdp_etudiant,mail_etudiant,classement) VALUES ('etu6','Scarlet','Erza','etu6','','9');
INSERT INTO Etudiants(login_etudiant,nom_etudiant,prenom_etudiant,mdp_etudiant,mail_etudiant,classement) VALUES ('etu7','Alberona','Kana','etu7','','10');
INSERT INTO Etudiants(login_etudiant,nom_etudiant,prenom_etudiant,mdp_etudiant,mail_etudiant,classement) VALUES ('etu8','Vermillon','Maevis','etu8','','5');
INSERT INTO Etudiants(login_etudiant,nom_etudiant,prenom_etudiant,mdp_etudiant,mail_etudiant,classement) VALUES ('etu9','Fullbuster','Grey','etu9','','12');
INSERT INTO Etudiants(login_etudiant,nom_etudiant,prenom_etudiant,mdp_etudiant,mail_etudiant,classement) VALUES ('etu10','Lockser','Juvia','etu10','','11');

INSERT INTO Chefs VALUES ('chef1','Franz','Hopper','chef1','');