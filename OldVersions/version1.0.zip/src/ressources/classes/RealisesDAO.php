<?php
class RealisesDAO extends DAO {
	protected $table = "Realises";
	protected $class = "Realise";
}
?>