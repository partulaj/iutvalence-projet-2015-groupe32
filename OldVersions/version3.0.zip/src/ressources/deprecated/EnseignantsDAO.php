<?php
class EnseignantsDAO extends DAO {
	protected $table = "Enseignants";
	protected $class = "Enseignant";
}
?>