insert into Utilisateurs (login,nom,prenom,mail,mdp,role) values ("chef1","Hashirama","Senju","","chef1","chef");
insert into Utilisateurs (login,nom,prenom,mail,mdp,role) values ("chef2","Uchiha","Madara","","chef2","chef");

insert into Utilisateurs (login,nom,prenom,mail,mdp,role) values ("ens1","Hatake","Kakashi","","ens1","enseignant");
insert into Utilisateurs (login,nom,prenom,mail,mdp,role) values ("ens2","Yuhi","Kurenai","","ens2","enseignant");

insert into Utilisateurs (login,nom,prenom,mail,mdp,role) values ("etu1","Uzumaki","Naruto","","etu1","etudiant");
insert into Utilisateurs (login,nom,prenom,mail,mdp,role) values ("etu2","Haruto","Sakura","","etu2","etudiant");
insert into Utilisateurs (login,nom,prenom,mail,mdp,role) values ("etu3","Uchiha","Sasuke","","etu3","etudiant");
insert into Utilisateurs (login,nom,prenom,mail,mdp,role) values ("etu4","Hyuga","Hinata","","etu4","etudiant");
insert into Utilisateurs (login,nom,prenom,mail,mdp,role) values ("etu5","Yamanaka","Ino","","etu5","etudiant");
insert into Utilisateurs (login,nom,prenom,mail,mdp,role) values ("etu6","Rock","Lee","","etu6","etudiant");