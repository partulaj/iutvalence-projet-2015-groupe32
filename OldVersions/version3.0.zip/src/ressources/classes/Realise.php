<?php
class Realise extends TableObject {
	static public $keyFieldsNames = array('no_tache','login'); // par défaut un seul champ
	public $hasAutoIncrementedKey = false;
}
?>